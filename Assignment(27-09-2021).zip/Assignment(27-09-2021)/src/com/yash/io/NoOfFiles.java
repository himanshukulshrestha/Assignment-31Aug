//	Count the number of files in a given folder 
//  ask end user to enter folder path on console and count no. of files in that folder.


package com.yash.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class NoOfFiles {
		
public static void main(String[] args) throws IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
     	System.out.println("Enter dirpath:");
     	String dirpath=br.readLine();
     	
     	File f = new File(dirpath);
  
        if(f.exists())
        {
            String arr[]=f.list();

            int n=arr.length;
            for (int i = 0; i < n ; i++) {
                System.out.println(arr[i]);
                File f1=new File(arr[i]);
                
                if(f1.isDirectory()) 
                    System.out.println("is a Folder");
            }
            System.out.println("No of files in this Folder is: "+n);
        }
        else
            System.out.println("Path not found");
    }	
}

