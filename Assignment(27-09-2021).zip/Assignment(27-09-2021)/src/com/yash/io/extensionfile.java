//Ask user to enter extension of file on console
  // search for all files with that extension in all drive of system.



package com.yash.io;
import java.io.*;
import java.io.File;
import java.io.FilenameFilter;
public class extensionfile {
		
	public static void main(String[] args) throws IOException {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the file Extension that you want to search:");
		String extension=br.readLine();
		
		File directoryPath=new File(extension);
		
		 FilenameFilter fname1 = new FilenameFilter(){
	         public boolean accept(File fname, String name) {
	            String lowercaseName = name.toLowerCase();
	            if (lowercaseName.endsWith(".txt")) {
	               return true;
	            } else {
	               return false;
	            }
	         }
	      };
	      String filesList[] = directoryPath.list(fname1);
	      System.out.println("List of the text files in the specified directory:");
	      for(String fileName : filesList) {
	         System.out.println(fileName);
	      }
	   }
	}