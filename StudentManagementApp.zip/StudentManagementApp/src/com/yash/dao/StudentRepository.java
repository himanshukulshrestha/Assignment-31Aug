package com.yash.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.entity.Student;
import com.yash.view.MainView;

public class StudentRepository {
	static MainView mvObj = new MainView();

	static List<Student> studentRecord = new ArrayList<>();

	Scanner input = new Scanner(System.in);

	public void registerStudent() throws InterruptedException {
		System.out.println("Student Registration");

		System.out.println("Enter ID for Student");
		int studentId = input.nextInt();
		System.out.print("Enter First Name :");
		String fname = input.next();

		System.out.print("Enter Last Name :");
		String lname = input.next();

		System.out.print("Enter Date of birth :");
		String dob = input.next();

		System.out.print("Enter gender :");
		String gender = input.next();

		System.out.print("Enter Course :");
		String course = input.next();

		Student student = new Student();

		student.setStudentId(studentId);
		student.setStudentFirstName(fname);
		student.setStudentLastName(lname);
		student.setStudentDob(dob);
		student.setStudentGender(gender);
		student.setStudentCourse(course);

		studentRecord.add(student);
		System.out.println("Student Registered");
		System.out.println("\n");

		mvObj.mainMenu();
	}

	public static void viewStudent() throws InterruptedException {
		try {
			int count = 1;
			for (Student obj : studentRecord) {
				System.out.println("1000" + count + obj);
				count++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			Thread.sleep(5000);
			mvObj.mainMenu();
			System.out.println();
		}

	}

	public void updateStudent() throws InterruptedException {

		System.out.println("Enter the Student Id for update");
		int id = input.nextInt();

		for (Student s : studentRecord) {
			if (s.getStudentId() == id) {
				System.out.println("studentId successfully" + s);
				System.out.println("What you want to update");
				System.out.println("1. FirstName");
				System.out.println("2. LastName");
				System.out.println("3. DOB");
				System.out.println("4. Gender");
				System.out.println("5. Course");

				int inputOption = input.nextInt();

				if (inputOption == 1) {
					String firstName = input.next();

					s.setStudentFirstName(firstName);
					System.out.println("FirstName Updated Successfully" + s);

				}

				if (inputOption == 2) {
					String lastName = input.next();

					s.setStudentLastName(lastName);
					System.out.println("lastName Updated Successfully" + s);

				}

				if (inputOption == 3) {
					String dob = input.next();

					s.setStudentDob(dob);
					System.out.println("DOB Updated Successfully" + s);

				}

				if (inputOption == 4) {
					String gender = input.next();

					s.setStudentGender(gender);
					System.out.println("gender Updated Successfully" + s);

				}

				if (inputOption == 5) {
					String course = input.next();

					s.setStudentCourse(course);
					System.out.println("course Updated Successfully" + s);

				}

			}

		}
		System.out.println();
		Thread.sleep(3000);
		mvObj.mainMenu();

	}

	public void removeStudent() throws InterruptedException {
		System.out.println("Enter student ID to be removed");
		int id = input.nextInt();
		studentRecord.remove(id);

		System.out.println("Student Removed Successfully");

		Thread.sleep(2000);
		mvObj.mainMenu();
		System.out.println();
	}

	public void exitMainMenu() {
		System.exit(0);
	}
}
