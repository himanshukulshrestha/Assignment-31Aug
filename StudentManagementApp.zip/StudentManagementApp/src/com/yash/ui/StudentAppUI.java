package com.yash.ui;

import com.yash.view.MainView;

public class StudentAppUI {

	public static void main(String[] args) throws InterruptedException
	{
		MainView mainView =new MainView();
		mainView.mainMenu();
		
	}
}
