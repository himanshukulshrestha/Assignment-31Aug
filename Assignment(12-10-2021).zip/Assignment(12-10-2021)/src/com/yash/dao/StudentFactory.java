package com.yash.dao;

@FunctionalInterface
public interface StudentFactory {
	public Student getInstance();
}
