package com.yash.dao;

public class Main {
	public static void main(String[] args) {
		
		StudentFactory factory=Student::new;
		Student student=factory.getInstance();
		student.setRollNo(1001);
		student.setFirstName("Aman");
		student.setLastName("Lashkari");
		student.setSemester1Marks(60);
		student.setSemester2Marks(70);
		student.setSemester3Marks(80);
		student.setSemester4Marks(66);
		student.setSemester5Marks(75);
		student.setSemester6Marks(87);
		
		ComputeAverage average = student::getAverageMarks;
		double averageScore = average.compute();
		System.out.println("Student Data is :\n"+student);
		System.out.println("\n Average is: "+averageScore);
	
	}
}

