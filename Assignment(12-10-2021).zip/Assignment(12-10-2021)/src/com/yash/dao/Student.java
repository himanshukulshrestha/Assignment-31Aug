package com.yash.dao;

public class Student {
	
	   int rollNo;
	   String firstName;
	   String lastName;
	   int semester1Marks;
	   int semester2Marks;
	   int semester3Marks;
	   int semester4Marks;
	   int semester5Marks;
	   int semester6Marks;
	   
	   
	   public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSemester1Marks() {
		return semester1Marks;
	}
	public void setSemester1Marks(int semester1Marks) {
		this.semester1Marks = semester1Marks;
	}
	public int getSemester2Marks() {
		return semester2Marks;
	}
	public void setSemester2Marks(int semester2Marks) {
		this.semester2Marks = semester2Marks;
	}
	public int getSemester3Marks() {
		return semester3Marks;
	}
	public void setSemester3Marks(int semester3Marks) {
		this.semester3Marks = semester3Marks;
	}
	public int getSemester4Marks() {
		return semester4Marks;
	}
	public void setSemester4Marks(int semester4Marks) {
		this.semester4Marks = semester4Marks;
	}
	public int getSemester5Marks() {
		return semester5Marks;
	}
	public void setSemester5Marks(int semester5Marks) {
		this.semester5Marks = semester5Marks;
	}
	public int getSemester6Marks() {
		return semester6Marks;
	}
	public void setSemester6Marks(int semester6Marks) {
		this.semester6Marks = semester6Marks;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", firstName=" + firstName + ", lastName=" + lastName + ", semester1Marks="
				+ semester1Marks + ", semester2Marks=" + semester2Marks + ", semester3Marks=" + semester3Marks
				+ ", semester4Marks=" + semester4Marks + ", semester5Marks=" + semester5Marks + ", semester6Marks="
				+ semester6Marks + "]";
	}
	
	public double getAverageMarks() {
		int TotalMarks=semester1Marks+semester2Marks+semester3Marks+semester4Marks+semester5Marks+semester6Marks;
		return TotalMarks/6;
		
	}

}
