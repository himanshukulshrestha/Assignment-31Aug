package com.yash.dao;

@FunctionalInterface
public interface ComputeAverage {
	public double compute();

}
