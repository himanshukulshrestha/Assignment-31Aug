package com.yash.lambda;

@FunctionalInterface
public interface LambdaMaxArray {
	public Integer max(Integer array[]);
}
