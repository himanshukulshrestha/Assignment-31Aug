package com.yash.lambda;

import java.util.Arrays;

public class lambdaArray{
	
	public static void main(String[] args) {
		Integer array[] = new Integer[] {100,29,45,67,43,54,123,324,56,78,353,125,56};
		System.out.println("Given Array---> ");
		System.out.println(Arrays.asList(array));
		LambdaMaxArray lma=(x)->{
			Integer[] copy = Arrays.copyOf(x, x.length);
			Arrays.sort(copy);
			return copy[x.length-1];
		};
		Integer max = lma.max(array);
		System.out.println("\nMax element of Array : "+max);
	}
}


