package com.yash.servies;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class ArrayThreadBasedSorting {
	public static void main(String[] args) {
		final int nThreads=3;
		Integer []arr1 = new Integer[] {89,23};
		Integer []arr2 = new Integer[] {23,34,78,90};
		Integer []arr3 = new Integer[] {20,60,39,45,65,23,42,12,1,56,98};
		Integer []arr4 = new Integer[] {12,34,67};

		Integer[][] array = new Integer[][] {arr1,arr2,arr3,arr4};
		
		ExecutorService executorService = Executors.newFixedThreadPool(nThreads);
		
		Set<Future<Integer[]>> futureSet = new LinkedHashSet<>();
		for (int i = 0; i < 4; i++) {
			Future<Integer[]> next = executorService.submit(new SortService(array[i]));
			futureSet.add(next);
		}
		futureSet.forEach(x->{
			try 
			{
				Integer[] integers = x.get();
				System.out.println("\nSorted array : "+ Arrays.asList(integers));
			} catch (ExecutionException | InterruptedException e) {
				e.printStackTrace();
			}
		});
			System.out.println(" \n========== Sorting completed ============");	
	}
}