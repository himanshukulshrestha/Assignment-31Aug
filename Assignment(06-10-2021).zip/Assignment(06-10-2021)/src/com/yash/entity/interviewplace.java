package com.yash.entity;

public class interviewplace {
	
	public String companyname;
	public String venue;
	public interviewplace(String companyname,String venue){
		super();
		this.companyname=companyname;
		this.venue=venue;
	}
	public void interviewprocess(String Name){
		System.out.println("Start the interview:"+Name);
		try {
			Thread.sleep(5000);
		}catch(InterruptedException e){
		e.printStackTrace();
		
	}
		System.out.println(Name+" interview completed");
		int ch = (int)(Math.random() * 10);
		
		if(ch>5) {
			System.out.println("===="+Name+" selected \n");
		}
		else {
			System.out.println("===="+Name+" rejected \n");			
		}
		
	}
	public String getCompanyName() {
		return companyname;
	}

	public String getVenue() {
		return venue;
	}

	}