package com.yash.entity;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class InterviewProcess {
	public static void main(String[] args) {
		interviewplace place=new interviewplace("YASH Technologies Pvt. Lmt.", "Indore");
		Lock lock=new ReentrantLock(true);
		
		Thread thread1=new Thread(new person("Aman Lashkari ","1001",place,lock));
		Thread thread2=new Thread(new person("Anil Solanki ","1002",place,lock));
		Thread thread3=new Thread(new person("Ankit Singh ","1003",place,lock));
		
		thread1.start();
		thread2.start();
		thread3.start();
	
	}
}