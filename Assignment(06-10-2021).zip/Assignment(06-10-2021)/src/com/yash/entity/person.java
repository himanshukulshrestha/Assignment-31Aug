package com.yash.entity;

import java.util.concurrent.locks.Lock;
public class person implements Runnable{

	private String Name;
	private String personId;
	private interviewplace place;
	private Lock lock;
	
	public person(String Name,String personId,interviewplace place,Lock lock){
		super();
		this.Name=Name;
		this.personId=personId;
		this.place=place;
		this.lock=lock;
		
	}
	
	@Override
	public void run() {
		System.out.println("\n"+Name+"personId:"+personId);
		lock.lock();
		place.interviewprocess(Name);
		lock.unlock();
		
	}
	
}
