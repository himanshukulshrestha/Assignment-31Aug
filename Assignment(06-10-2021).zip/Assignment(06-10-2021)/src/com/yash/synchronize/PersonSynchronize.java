package com.yash.synchronize;

import com.yash.entity.interviewplace;

public class PersonSynchronize implements Runnable {
	private String Name;
	private int personId;
	private interviewplace place;
	
	public PersonSynchronize(String Name, int resumeNo,interviewplace place) {
		super();
		this.Name =Name;
		this.personId = resumeNo;
		this.place=place;
	}

	@Override
	public void run() {
		System.out.println("\n"+Name+" is waiting, Resume no. : "+personId);
		synchronized(place) {
			place.interviewprocess(Name);
		}
	}	
}