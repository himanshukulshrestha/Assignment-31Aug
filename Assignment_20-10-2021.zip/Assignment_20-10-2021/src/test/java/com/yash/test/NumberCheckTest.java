package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import com.yash.service.MobileCheck;
import com.yash.service.NumberCheck;

class NumberCheckTest {
	
	Answer<Boolean> answer = (invocation)->{
		Object[] args = invocation.getArguments();
		String contact = (String)args[0];
		Pattern compile = Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher = compile.matcher(contact);
		if(matcher.find()) {
			return true;
		}
		return false;
	};

	@Mock
	private MobileCheck checkMobile;
	
	@InjectMocks
	private NumberCheck numberCheck;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@DisplayName("Test 1: Check if mobile number is of 10 digits and must start with 6-9")
	@Test
	void testMobileNumberCheck_Positive() 
	{
		String mobileNumber="9875564434";
		when(checkMobile.CheckMobileNumber(mobileNumber)).then(answer);
		boolean actual = numberCheck.check(mobileNumber);
		assertTrue(actual);
		
	}
	
	@DisplayName("Test 2: Check if mobile number is of 10 digits")
	@Test
	void testMobileNumberCheck_Negative1() 
	{
		String mobileNumber="9456455";
		when(checkMobile.CheckMobileNumber(mobileNumber)).then(answer);
		boolean actual = numberCheck.check(mobileNumber);
		assertTrue(!actual);
	}

	@DisplayName("Test 3: Check for characters and special characters that is not  allowed")
	@Test
	void testMobileNumberCheck_Exception() 
	{
		try {
			String mobileNumber="cs09834732";
			when(checkMobile.CheckMobileNumber(mobileNumber))
			.thenThrow(new Exception("Special Character not allowed"));
			numberCheck.check(mobileNumber);
			assertTrue(false);
		}
		catch(Exception e) {
			assertTrue(true);
		}
	}

}