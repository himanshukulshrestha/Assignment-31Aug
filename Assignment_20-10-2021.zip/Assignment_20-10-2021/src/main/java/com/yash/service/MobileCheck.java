package com.yash.service;

public interface MobileCheck {

	public boolean CheckMobileNumber(String number);
}
