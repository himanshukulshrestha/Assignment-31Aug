package com.yash.Repository;

import java.io.File;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Repository{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Repository.class);
	
		public static List<Question>  CollectJava;
		public static List<Question>  ExceptionsOfJava;
		
		public static List<Question> readCollection()
		{
			String filepath= "C:\\\\Users\\\\himanshu.kulshrestha\\\\Downloads\\\\quiz (2)\\\\quiz\\\\CollectionsOfJava.xml";
			File xmlfile=new File(filepath);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
			DocumentBuilder db;
			
			try {
				db=dbf.newDocumentBuilder(); 
				Document doc = db.parse(xmlfile);  
				doc.getDocumentElement().normalize();  
				NodeList nodeList = doc.getElementsByTagName("Question");
				CollectJava = new ArrayList<Question>();
		
				for (int i = 0; i < nodeList.getLength(); i++)   
				{  
					CollectJava.add(get(nodeList.item(i)));
				}
				
			}catch (SAXException | ParserConfigurationException | IOException   e)
			{
				e.printStackTrace();
				LOGGER.error("Failed due to : "+e.getMessage()+e);
				
			}
			return CollectJava;
			
		}	
		public static List<Question> readException()
		{
			String filepath= "C:\\Users\\himanshu.kulshrestha\\Downloads\\quiz (2)\\quiz\\ExceptionsOfJava.xml";
			File xmlfile=new File(filepath);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
			DocumentBuilder db;
			
			try {
				db=dbf.newDocumentBuilder(); 
				Document doc = db.parse(xmlfile);  
				doc.getDocumentElement().normalize();  
				NodeList nodeList = doc.getElementsByTagName("Question");
				ExceptionsOfJava = new ArrayList<Question>();
		
				for (int i = 0; i < nodeList.getLength(); i++)   
				{  
					ExceptionsOfJava.add(get(nodeList.item(i)));
				}
				
			}catch (SAXException | ParserConfigurationException | IOException   e)
			{
				e.printStackTrace();
				LOGGER.error("Failed due to : "+e.getMessage()+e);
			}
			return ExceptionsOfJava;
			
		}	
	
	
	
		 private static Question get(Node node) {
		    
		        Question data = new Question();
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            Element element = (Element) node;
		            data.setId(Integer.parseInt(getTagValue("Id", element)));
		            data.setQuestion(getTagValue("Questions", element));
		            data.setOption1(getTagValue("Option1", element));
		            data.setOption2(getTagValue("Option2", element));
		            data.setOption3(getTagValue("Option3", element));
		            data.setOption4(getTagValue("Option4", element));
		            data.setCorrect(getTagValue("Correct", element));
		        }
		        return data;
		    }
		 private static String getTagValue(String tag, Element element) {
		        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
		        Node node = (Node) nodeList.item(0);
		        return node.getNodeValue();
		    }
}
