package com.yash.Repository;

import java.util.HashMap;
import java.util.Map;

import com.yash.entity.User;

public class UserRepository {
private static Map<String,User> userInfo=new HashMap<>();
	
	public static Map<String,User> loadUserInfo(){
		userInfo.put("Aman", new User("Aman","Aman123","Aman","Lashkari"));
		userInfo.put("Avinash", new User("avinash1234","12345","Avinash","Vishwakarma"));
		userInfo.put("Amay", new User("Amay","123456","Amay","mandloi"));
		userInfo.put("Himanshu", new User("Himanshu","123456","Himanshu","Kulshrestha"));
		userInfo.put("Amit", new User("Amit","123456","Amit","Verma"));
		return userInfo;
	}

}
