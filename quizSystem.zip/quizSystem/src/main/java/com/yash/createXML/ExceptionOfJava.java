package com.yash.createXML;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ExceptionOfJava 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionOfJava .class);
	public static void createException()
	{ 
		 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder;
	        try {
	            dBuilder = dbFactory.newDocumentBuilder();
	            Document doc = dBuilder.newDocument();
	            
	            Element rootElement = doc.createElement("ExceptionOfJava");

	            doc.appendChild(rootElement);
                rootElement.appendChild(createUserElement(doc, "1", "Which keyword is used to monitor statement for exception?", "try", "catch", "throw","throws","try"));
                rootElement.appendChild(createUserElement(doc, "2", "If a statement tries to divide by zero which exception is thrown?", "NullPointerException", "NumberFormatException", "ArithemeticException","None of these","ArithemeticException"));
                rootElement.appendChild(createUserElement(doc, "3", "Which method is used to print the description of the exception?", "printStackTrace()", "printExceptionMessage()", "printStackMessage()","printExceptionTrace()","printStackTrace()"));
                rootElement.appendChild(createUserElement(doc, "4", "Which of the following must be true of the object thrown by a throw statement?", "It must be assignable to the Throwable type", "It must be assignable to the Error type", "It must be assignable to the Exception type","It must be assignable to the String type","It must be assignable to the Throwable type"));
                rootElement.appendChild(createUserElement(doc, "5", "what is checked exception?", "Error", "Runtime Error", "SQL Exception","None Of the Above","SQL Exception"));
                rootElement.appendChild(createUserElement(doc, "6", "String s=&quot;abc&quot;; Integer i=Integer.parseInt(s); what is output?", "Runtime Exception", "NumberFormatedException", "compile time error","None of the above","compile time error"));
                rootElement.appendChild(createUserElement(doc, "7", "When does Exceptions in Java arises in code sequence?", "Run Time", "Compilation Time", "Can Occur Any Time","None of the mentioned","Run Time"));
                rootElement.appendChild(createUserElement(doc, "8", "Which of these keywords is not a part of exception handling?", "try", "Finally", "catch","thrown","thrown"));
                rootElement.appendChild(createUserElement(doc, "9", " Which of these keywords must be used to monitor for exceptions?", "try", "finally", "thrown","catch","try"));
                rootElement.appendChild(createUserElement(doc, "10", "Which of these keywords is used to manually throw an exception?", "try", "finally", "catch","throw","throw"));
                
    
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
	            Transformer transformer = transformerFactory.newTransformer();
	            
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	            DOMSource source = new DOMSource(doc);

	            StreamResult file = new StreamResult(new File("C:\\Users\\himanshu.kulshrestha\\Downloads\\quiz (2)\\quiz\\ExceptionsOfJava.xml"));

	            transformer.transform(source, file);

	        } catch (Exception e) {
	            e.printStackTrace();
	            LOGGER.error("Failed due to : "+e.getMessage()+e);
	        }
	    }


private static Element createUserElement(Document doc, String Id, String Questions , String Option1 , String Option2,
     String Option3,String Option4,String Correct)
 {

     Element data = doc.createElement("Question");

     data.appendChild(createUserElements(doc, data, "Id", Id));
     
     data.appendChild(createUserElements(doc, data, "Questions", Questions));

     data.appendChild(createUserElements(doc, data, "Option1", Option1));

     data.appendChild(createUserElements(doc, data, "Option2", Option2));

     data.appendChild(createUserElements(doc, data, "Option3", Option3));
     
     data.appendChild(createUserElements(doc, data, "Option4", Option4));
     
     data.appendChild(createUserElements(doc, data, "Correct", Correct));

     return data;
 }

private static Element createUserElements(Document doc, Element element, String name, String value) 
 {
     Element node = doc.createElement(name);
     node.appendChild(doc.createTextNode(value));
     return node;
 }

}
