package com.yash.model;

import com.yash.entity.User;

public class UserModel {
	private String userName;
	private String password;
	private boolean isAuthenticated;
	
	public UserModel() {}
	
	public UserModel(User user) {
		// TODO Auto-generated constructor stub
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isAuthenticated() {
		return isAuthenticated;
	}
	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}
	

}
