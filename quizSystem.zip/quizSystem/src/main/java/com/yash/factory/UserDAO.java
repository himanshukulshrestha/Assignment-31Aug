package com.yash.factory;

import com.yash.DAO.AuthUserDAO;
import com.yash.DAO.MemoryAuthImpl;

public class UserDAO {
	public static AuthUserDAO getInstance() {
		AuthUserDAO authUserDAO=new MemoryAuthImpl();
		return authUserDAO;
}
}