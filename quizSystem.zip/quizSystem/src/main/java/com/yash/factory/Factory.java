package com.yash.factory;

import javax.xml.parsers.ParserConfigurationException;

import com.yash.createXML.CollectionOfJava;
import com.yash.createXML.ExceptionOfJava;

public class Factory
{
    
	@SuppressWarnings("static-access")
	public  void factory() throws ParserConfigurationException, Throwable 
    {
    	
    	CollectionOfJava collection= new CollectionOfJava();
    	collection.createCollection();
    	
    	ExceptionOfJava exception=new ExceptionOfJava();
    	exception.createException();
    }
}