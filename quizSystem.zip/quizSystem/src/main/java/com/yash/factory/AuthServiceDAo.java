package com.yash.factory;

import com.yash.service.AuthService;
import com.yash.service.AuthServiceImpl;

public class AuthServiceDAo {

	public static AuthService getInstance() {
		AuthService authService=new AuthServiceImpl();
		return authService;
}
}