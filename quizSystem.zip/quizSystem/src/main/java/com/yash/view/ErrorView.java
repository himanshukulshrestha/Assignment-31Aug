package com.yash.view;

public class ErrorView {
	LoginView loginView = new LoginView();
	public void authError() throws Exception {

		System.err.println("Either username or password is incorrect");
		System.out.println();
		loginView.logindata();
	}

}
