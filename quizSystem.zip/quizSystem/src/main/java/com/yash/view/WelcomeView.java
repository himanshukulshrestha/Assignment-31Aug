package com.yash.view;

import com.yash.DAO.Display;
import com.yash.model.UserModel;

public class WelcomeView {
	static String userName =null;
	public void welcomeUser(UserModel user){
			userName= user.getUserName();
			System.out.println("\nWelcome,"+user.getUserName()+" to the Quiz");
			System.out.println("\nSelect Topic of the test----->");
			System.out.println("\n1- Collections of JAVA");
			System.out.println("\n2- Exception Handling of JAVA");
			System.out.println("\nSelect the Topic and press Enter");
		
			Display display = new Display();
			display.displayQuestion(); 
		}
	
	public static String userName() {
		return userName;
	}
	}

