package com.yash.DAO;

import java.util.Map;

import com.yash.entity.User;
import com.yash.Repository.UserRepository;

public class MemoryAuthImpl implements AuthUserDAO {

	private Map<String,User> userDetails;
	public MemoryAuthImpl() {
		this.userDetails=UserRepository.loadUserInfo();
	}
	
	
	public boolean authUser(String userName, String password) {

		User user=userDetails.get(userName);
		if(user!=null) {
			String passwordFromUserDetails=user.getPassword();
			if(passwordFromUserDetails.equals(password)) {
				return true;
			}else {
				return false;
			}
		}else {
		return false;
		}
	}

}
