package com.yash.DAO;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Scanner;
import java.util.Timer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yash.Repository.Question;
import com.yash.Repository.Repository;
import com.yash.model.UserModel;
import com.yash.view.WelcomeView;

public class Display extends Repository {

	private final Logger LOGGER = LoggerFactory.getLogger(Display.class);
	LocalDate localdate = LocalDate.now();
	LocalTime localTime = LocalTime.now();
	
	Scanner sc = new Scanner(System.in);
	String ans;
	int count;
	int i = 1;

	
	@SuppressWarnings("static-access")
	public void displayQuestion() {
		Repository repo = new Repository();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String input = sc.next();
		if (!(input.equals("1") || input.equals("2"))) {
			System.err.print("Kindly enter the correct input");
			displayQuestion();
		}
		
		switch (input) {
		case "1":
			for (Question Q : repo.CollectJava) {

				System.out.println(
						"=================================================================================================");

				if (i == 7 || i == 8) {
					System.out.println("Question:" + i + ") " + Q.getQuestion());
					System.out.println("1) " + Q.getOption1());
					System.out.println("2) " + Q.getOption2());
				} else {
					System.out.println("Question:" + i + ") " + Q.getQuestion());
					System.out.println("1) " + Q.getOption1());
					System.out.println("2) " + Q.getOption2());
					System.out.println("3) " + Q.getOption3());
					System.out.println("4) " + Q.getOption4());
					System.out.println();
				}

				System.out.println("Enter Your Answer and press Enter: ");

				ans = sc.next();
				boolean flag1 = true;

				while (flag1) {

					if (!((ans.equals("1") || ans.equals("2") || ans.equals("3") || ans.equals("4")))) {
						LOGGER.error("Incorrect input : " + ans);
						System.err.print("Kindly enter the correct input");
						ans = sc.next();
					}

					else {
						flag1 = false;
					}
				}

				switch (ans) {
				case "1":
					if (Q.getOption1().equals(Q.getCorrect())) {
						count++;

					}
					break;

				case "2":
					if (Q.getOption2().equals(Q.getCorrect())) {
						count++;
					}
					break;
				case "3":
					if (Q.getOption3().equals(Q.getCorrect())) {
						count++;
					}
					break;
				case "4":
					if (Q.getOption4().equals(Q.getCorrect())) {
						count++;
					}
					break;
				}

				i++;

			}

			System.out.println("=====================Test End=====================");
			System.out.println("Date: "+localdate+"			Time: "+localTime.truncatedTo(ChronoUnit.MINUTES));
			System.out.println();
			System.out.println(WelcomeView.userName()+ " your Score Card :");
			System.out.println();
			System.out.println("Your Score is : " + (count) + " out of 10");
			System.out.println("Your percentage is:  " + (count * 10) + "%");
			if (count >= 4) {
				System.out.println("Your result is : PASS");
			} else
				{
				localdate = localdate.plusDays(15);
				System.out.println("Your result is : FAIL");
				System.out.println("Now you can give the test after 15 days and the date is : "+localdate);
				}
			storeDate();
			break;

		case "2":
			for (Question Q : repo.ExceptionsOfJava) {
				System.out.println(
						"================================================================================================");

				System.out.println("Question:" + i + ") " + Q.getQuestion());
				System.out.println("1) " + Q.getOption1());
				System.out.println("2) " + Q.getOption2());
				System.out.println("3) " + Q.getOption3());
				System.out.println("4) " + Q.getOption4());
				System.out.println();

				System.out.println("Enter Your Answer and press Enter: ");
				ans = sc.next();

				boolean flag = true;
				while (flag) {
					if (!((ans.equals("1") || ans.equals("2") || ans.equals("3") || ans.equals("4")))) {
						System.err.print("Kindly enter the correct input");
						LOGGER.error("Incorrect input : " + ans);
						ans = sc.next();
					} else {
						flag = false;
					}
				}

				switch (ans) {
				case "1":
					if (Q.getOption1().equals(Q.getCorrect())) {
						count++;
					}
				case "2":
					if (Q.getOption2().equals(Q.getCorrect())) {
						count++;
					}
				case "3":
					if (Q.getOption3().equals(Q.getCorrect())) {
						count++;
					}
				case "4":
					if (Q.getOption4().equals(Q.getCorrect())) {
						count++;
					}
				}
				i++;
			}
			System.out.println("=======================Test End============================");
			System.out.println("Date: "+localdate+"			Time: "+localTime.truncatedTo(ChronoUnit.MINUTES));
			System.out.println(WelcomeView.userName()+ " your Score Card :");
			System.out.println("Your Score is : " + (count) + " out of 10");
			System.out.println("Your Percent is: " + (count * 10) + "%");
		
			if (count >= 4) {
				System.out.println("Your result is : PASS");
			} else {
				localdate = localdate.plusDays(15);
				System.out.println("Your result is : FAIL");
				System.out.println("Now you can give the test after 15 days and the date is : "+localdate);
				
			}
			storeDate();
			break;
		}
	}

	public void storeDate() {

		try {
			
			    String filename= "C:\\Users\\himanshu.kulshrestha\\Documents\\Others\\QuizScore.dat";
			    
			    FileWriter fw = new FileWriter(filename,true); //the true will append the new data
			    fw.write("\n"); //appends the string to the file
			    fw.write("-----------------------------------------------------------------"); //appends the string to the file
			    fw.write("\n"+WelcomeView.userName()+ " your Score Card :");
			    fw.write("\n\nScore is : " + (count) + " out of 10"); //appends the string to the file
			    fw.write("\nPercent is: " + (count * 10) + "%"); //appends the string to the file
			    
			    if(count>=4) {  	
			    	fw.write("\nResult : PASS");
			    }
			    else
			    	fw.write("\nResult : FAIL");
			    
			    fw.close();

		} catch (Exception e) {
			System.err.print("Error" + e);
			LOGGER.error("Failed due to : "+e.getMessage()+e);
		}

	}
	
}
