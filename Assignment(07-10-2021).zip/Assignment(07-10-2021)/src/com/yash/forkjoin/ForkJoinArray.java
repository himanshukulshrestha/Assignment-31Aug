package com.yash.forkjoin;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ForkJoinArray extends RecursiveTask<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static long sum=0;
	private final int[] SumOfArray;
	private final int threshold;
	private int start;
	private int end;
	private int middle;
	
	public ForkJoinArray(int[] SumOfArray,int start,int end,int threshold) {
		super();
		this.SumOfArray=SumOfArray;
		this.threshold=threshold;
		this.start=start;
		this.end=end;
	}
	@Override
	protected Long compute() {
		if(end-start>threshold) {
			for(int i=start;i<=end;i++) {
				sum+=SumOfArray[i];
			}
			return sum;
		}else {
			middle=end-start/2 +start;
			ForkJoinArray t1=new ForkJoinArray(SumOfArray,start,middle,threshold);
			t1.fork();
			ForkJoinArray t2 = new ForkJoinArray(SumOfArray, middle, end, threshold);
			long addExact = Math.addExact(t2.compute(), t1.join());
			return addExact;
		}
		
	}

	public static void main(String[] args) throws InterruptedException 
	{
		long verifySum=0;
		ForkJoinPool fork = new ForkJoinPool();
		int data[] = new int[100];
		for(int i=0;i<data.length;i++) {
			int x = (int)(Math.random() * 100);
			verifySum+=x;
			data[i]=x;
		}	
		
		System.out.println("============ Given Array =============");
		for (int i = 0; i < data.length; i++) {
			System.out.print(data[i]+",");
		}
				
		ForkJoinArray task = new ForkJoinArray(data, 0, data.length-1,data.length/400);
		Long result = fork.invoke(task);
		System.out.println("\n\n============  Verifying Summation ============ ");
		Thread.sleep(1000);
		System.out.println("Summation from FORK-JOIN ARRAY  : "+result);
		System.out.println("Actual Sum Of Array : "+verifySum);
		if(verifySum==result) {
			System.out.println("============  Verified  ==============");
		}
		else {
			System.out.println("============  Incorrect ============ ");
		}
	}

}